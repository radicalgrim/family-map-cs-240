package service.dummyData;

public class FemaleNames {
  String[] data;

  public FemaleNames() {
  }

  public FemaleNames(String[] data) {
    this.data = data;
  }

  public String[] getData() {
    return data;
  }

  public void setData(String[] data) {
    this.data = data;
  }
}
